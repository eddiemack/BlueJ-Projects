These are all of the world files for the book. The files are text files with DOS end lines. 
